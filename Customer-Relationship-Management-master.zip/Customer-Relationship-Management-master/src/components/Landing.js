import React, {Component} from 'react'

class Landing extends Component {
    render() {
        return (
        <div id="landing-page-container">
            <h1 id="landing-page-header">Client Relationship Managment System</h1>
            <h2 id="landing-page-subheader">The system that will save you time and money</h2>
        </div>)
    }
}
export default Landing